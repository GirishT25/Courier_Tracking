package example;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.*;

@SuppressWarnings("serial")
@WebServlet("/CourierTracking")
public class CourierServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/CourierTracking";
    private static final String DB_USER = "root"; // change to your MySQL username
    private static final String DB_PASSWORD = "Girish@25"; // change to your MySQL password

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doOptions(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle OPTIONS request (pre-flight request for CORS)
        response.setHeader("Access-Control-Allow-Origin", "http://localhost:5173");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
        response.setStatus(HttpServletResponse.SC_OK);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Add CORS headers for POST requests
        response.setHeader("Access-Control-Allow-Origin", "http://localhost:5173");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");

        // Get form data from the request
        String trackingNumber = request.getParameter("trackingNumber");
        String senderName = request.getParameter("senderName");
        String receiverName = request.getParameter("receiverName");
        String status = request.getParameter("status");
        String deliveryDate = request.getParameter("deliveryDate");

        // Establish a connection to the database
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            
            // SQL query to insert the courier data
            String sql = "INSERT INTO couriers (tracking_number, sender_name, receiver_name, status, delivery_date) "
                        + "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, trackingNumber);
                pstmt.setString(2, senderName);
                pstmt.setString(3, receiverName);
                pstmt.setString(4, status);
                pstmt.setDate(5, Date.valueOf(deliveryDate));

                // Execute the query
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    response.setStatus(HttpServletResponse.SC_OK);
                    response.getWriter().write("{\"message\": \"Courier data inserted successfully!\"}");
                } else {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"message\": \"Failed to insert courier data!\"}");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"message\": \"Database error: " + e.getMessage() + "\"}");
        }
    }
}
